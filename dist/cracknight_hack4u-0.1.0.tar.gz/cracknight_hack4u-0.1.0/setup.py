
from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as file:
    long_description = file.read()

setup(
    name='cracknight_hack4u',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[],
    author='Crack Night',
    description='Biblioteca para consultar cursos de Hack4U',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://hack4u.io'
)

